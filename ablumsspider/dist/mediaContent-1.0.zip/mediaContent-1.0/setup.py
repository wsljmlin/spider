#!/usr/bin/env python
#encoding=UTF-8
from distutils.core import setup
setup(name='mediaContent',
      version='1.0',
      description='My Blog Distribution Utilities',
      author='chishixn',
      author_email='chi-shixing@163.com',
      url='http://blog.liuts.com',
      py_modules=['mediaContent'],
     )