#!/usr/bin/env python
#encoding=UTF-8
import re
import sys
import json
import os
import time
import copy
from mediaContent import BASE_CONTENT
from mediaContent import PROGRAM_SUB
from bs4 import BeautifulSoup
#我的吸血鬼男友
#隐秘动机
#先生你哪位
from spiderModel.spiderTool import spiderTool


class all_youku_movie():
    def __init__(self):
        print "Do spider all_youku_movie."
        self.program = copy.deepcopy(BASE_CONTENT["program"])
        self.program_sub = PROGRAM_SUB
        self.seedBase = ["http://www.youku.com/v_olist/c_96_g__a__sg__mt__lg__q__s_6_r_0_u_0_pt_1_av_0_ag_0_sg__pr__h__d_1_p_1.html"
                        ,"http://www.youku.com/v_olist/c_96_g__a__sg__mt__lg__q__s_6_r_0_u_0_pt_1_av_0_ag_0_sg__pr__h__d_1_p_1.html"
                        ,"http://www.youku.com/v_olist/c_96_g__a__sg__mt__lg__q__s_6_r_0_u_0_pt_1_av_0_ag_0_sg__pr__h__d_1_p_2.html"
                        ,"http://www.youku.com/v_olist/c_96_g__a__sg__mt__lg__q__s_6_r_0_u_0_pt_1_av_0_ag_0_sg__pr__h__d_1_p_3.html"
                        ,"http://www.youku.com/v_olist/c_96_g__a__sg__mt__lg__q__s_6_r_0_u_0_pt_1_av_0_ag_0_sg__pr__h__d_1_p_4.html"
        ]
        self.seedList = []
        self.dataDir = '.' + os.path.sep + 'data'
        self.today = time.strftime('%Y%m%d', time.localtime())
        self.jsonData = ""
    #     self.dataFile = spiderTool.openFile(self.dataDir + os.path.sep + "all_youku_movie_" + self.today + ".txt")
    #
    # def __del__(self):
    #     if self.dataFile is not None:
    #         self.dataFile.close()

    def doProcess(self):
        for seed in self.seedBase:
            self.seedList = []
            seedList = []
            doc = spiderTool.getHtmlBody(seed)
            soup = BeautifulSoup(doc, from_encoding="utf8")
            seed_P = soup.find("div", attrs={"class": "box-series"})
            if seed_P is not None:
                seedList = seed_P.find_all("div", attrs={"class": "p-thumb"})
            for each in seedList:
                a_tag = each.find("a")
                if a_tag is not None:
                    subSeed = a_tag.get("href")
                    if subSeed is not None:
                        self.seedList.append(subSeed)
            self.seedSpider()

    def seedSpider(self):
        for seed in self.seedList:
            self.program = copy.deepcopy(BASE_CONTENT["program"])
            self.firstSpider(seed)
            self.program["ptype"] = "电影".decode("utf8")
            self.program['website'] = '优酷'.decode("utf8")
            self.program['getTime'] = time.strftime('%Y-%m-%d %H:%M:%S', time.localtime())
            self.program['totalSets'] = 1
            #print self.program["name"],self.program['totalSets']
            if self.program['name'] == '' or self.program['name'] is None \
                    or self.program['mainId'] == ''or self.program['mainId'] is None \
                    or self.program['totalSets'] < 1:
                continue

            json.dumps(PROGRAM_SUB)
            content = {'program': self.program}
            str = json.dumps(content)
            self.jsonData = str + '\n'
            #self.dataFile.write(str + '\n')

    def firstSpider(self, seed):
        point = 0.0
        poster = ""
        pcUrl = ""
        name = ""
        shootYear = ""
        alias = ""
        area = ""
        star = ""
        director = ""
        ctype = ""
        playTimes = 0
        intro = ""
        playLength = ""
        mainId = ""

        doc = spiderTool.getHtmlBody(seed)
        soup = BeautifulSoup(doc, from_encoding="utf8")

        seed_Re = re.search(r'http://www\.youku\.com/show_page/id', seed)
        if not seed_Re:
            seed_P = soup.find('h1', attrs={'class': 'title'})
            if seed_P is not None:
                seed_aTag = seed_P.find('a')
                if seed_aTag is not None:
                    seed = seed_aTag.get('href')
                    doc = spiderTool.getHtmlBody(seed)
                    soup = BeautifulSoup(doc, from_encoding="utf8")

        point_P = soup.find('dt',attrs={'class': 'score_num_wrap clearfix'})
        if point_P is not None:
            point_tag = point_P.find('strong')
            if point_tag is not None:
                point = point_tag.get_text()

        poster_p = soup.find("ul",attrs={'class':'baseinfo'})
        if poster_p is not None:
            img_tag = poster_p.find('img')
            if img_tag is not None:
                poster = img_tag.get("src")
                name = img_tag.get("alt")

            pcUrl_p = poster_p.find('li', attrs={'class': 'link'})
            if pcUrl_p is not None:
                if pcUrl_p.find('a') is not None:
                    pcUrl = pcUrl_p.find('a').get('href')


        alias_P = soup.find('span',attrs={'class': 'alias'})
        if alias_P is not None:
            alias = alias_P.get('title')

        playLength_P = soup.find('span',attrs={'class': 'duration'})
        if playLength_P is not None:
            if re.search(r'\d+', playLength_P.get_text()):
                playLength = re.search(r'\d+', playLength_P.get_text()).group()

        shootYear_p = soup.find('span',attrs={'class': 'pub'}, text=re.compile(r'.*?\d\d\d\d.*?'.decode('utf8')))
        if shootYear_p is not None:
            shootYear = re.search(r'\d\d\d\d'.decode('utf8'),shootYear_p.get_text()).group()

        area_P = soup.find('span',attrs={'class': 'area'})
        if area_P is not None:
            area_list = []
            for each in area_P.find_all("a"):
                area_list.append(each.get_text())
            area = ",".join(area_list)

        ctype_pp = soup.find('ul', attrs={'class': 'baseinfo'})
        if ctype_pp is not None:
            ctype_P = ctype_pp.find('span', attrs={'class': 'type'})
            if ctype_P is not None:
                ctype_list = []
                for each in ctype_P.find_all("a"):
                    ctype_list.append(each.get_text())
                ctype = ",".join(ctype_list)

        star_P = soup.find("span", attrs={"class": "actor"})
        if star_P is not None:
            star_list = []
            for each in star_P.find_all('a'):
                star_list.append(each.get_text())
            star = ",".join(star_list)

        director_P = soup.find("span", attrs={"class": "director"})
        if director_P is not None:
            director_list = []
            for each in director_P.find_all('a'):
                director_list.append(each.get_text())
            director = ",".join(director_list)

        playTimes_P = soup.find('span', attrs={'class': 'play'})
        if playTimes_P is not None:
            playTimesStr = playTimes_P.get_text()
            playTimes_list = re.findall(r'(\d+)', playTimesStr)
            playTimes = long(''.join(playTimes_list))

        content_p = soup.find('span',  attrs={"class": "long"})
        if content_p is not None:
                intro = content_p.get_text().strip()

        if re.match(r'http://www\.youku\.com/show_page/(id_(.+))\.html', seed):
            mainId = re.match(r'http://www\.youku\.com/show_page/(id_(.+))\.html', seed).group(1)

        self.program["name"] = spiderTool.changeName(name)
        self.program['pcUrl'] = pcUrl
        self.program["alias"] = spiderTool.changeName(alias)
        self.program["point"] = float(point)
        self.program['poster'] = spiderTool.listStringToJson('url',poster)
        self.program['star'] = spiderTool.listStringToJson('name',star)
        self.program['director'] = spiderTool.listStringToJson('name',director)
        self.program['ctype'] = spiderTool.listStringToJson('name',ctype)
        self.program['shootYear'] = shootYear
        self.program['area'] = spiderTool.listStringToJson('name', area)
        self.program['playTimes'] = long(playTimes)
        self.program['intro'] = intro
        self.program['mainId'] = mainId
        self.program_sub['playLength'] = playLength + ':' + '00'
        self.secondSpider()

    def secondSpider(self):
            self.program_sub['setNumber'] = 1
            self.program_sub['setName'] = self.program["name"]
            self.program_sub['webUrl'] = self.program['pcUrl']
            self.program['programSub'].append(self.program_sub)

if __name__ == '__main__':
    app = all_youku_movie()
    if len(sys.argv) > 1:
        app.seedList = spiderTool.readSeedList(sys.argv[1])
        app.seedSpider()
    else:
        app.doProcess()