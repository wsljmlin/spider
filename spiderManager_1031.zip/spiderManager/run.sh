#!/bin/bash
#########################
. ~/.bashrc 
. ~/.profile
#########################
nohup python run.py &
