#!/usr/bin/env python
#encoding=UTF-8
from flask.ext.sqlalchemy import SQLAlchemy

db = SQLAlchemy()